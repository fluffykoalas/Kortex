# Copyright (c) 2020 Fluffy Koalas open source software. This file is licensed under the MIT license. #


class InvalidToken(Exception):
    pass


class SecurityRiskError(Exception):
    pass
